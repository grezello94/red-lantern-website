/*
 * Red Lantern Print Bridge
 *
 * Run this on the restaurant computer that has the LAN/USB printers installed:
 *   npm run print-bridge
 *
 * It keeps a durable workstation identity, repairs the local Windows printing
 * service, and accepts only print jobs assigned to this restaurant computer.
 */
const http = require('http');
const net = require('net');
const { execFile, spawn } = require('child_process');
const crypto = require('crypto');
const { printerCapabilities, printerSupports, resolveSystemPrinter } = require('./printer-domain');
const Addons = require('./addons-domain');
const fs = require('fs/promises');
const fsSync = require('fs');
const os = require('os');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');

const PORT = Number(process.env.PRINT_BRIDGE_PORT || 9124);
// Keep this in sync with downloads/print-bridge-release.json. Operations uses
// that signed-off release record to tell staff whether this computer is current.
const BRIDGE_VERSION = '2026.10.08.2';
const BRIDGE_CAPABILITIES = Object.freeze({
  testPrint: true,
  setupStatus: true,
  durablePrintJobs: true,
  queueBindings: true,
  durablePairing: true,
  backgroundConfigSync: true,
});
const PRINT_JOB_LEASE_MS = Math.max(
  30000,
  Number(process.env.PRINT_BRIDGE_JOB_LEASE_MS || 2 * 60 * 1000)
);
const PRINT_COMMAND_TIMEOUT_MS = Math.max(
  10000,
  Number(process.env.PRINT_BRIDGE_PRINT_TIMEOUT_MS || 30000)
);
const storageDir =
  process.env.PRINT_BRIDGE_DATA_DIR || path.join(os.homedir(), '.red-lantern-print-bridge');
const configFile = path.join(storageDir, 'printer-config.json');
const queueFile = path.join(storageDir, 'kot-queue.json');
const ledgerFile = path.join(storageDir, 'orders-ledger.sqlite');
const workstationFile = path.join(storageDir, 'workstation.json');
let ledger = null;
let shuttingDown = false;
let workstationIdentityPromise = null;
let windowsSpoolerCheckPromise = null;
let windowsSpoolerCheck = {
  checkedAt: 0,
  result: { attempted: false, recovered: false },
};
const networkReachability = new Map();
const networkProbePromises = new Map();
let windowsPrinterSnapshotPromise = null;
let windowsPrinterSnapshotCache = null;
const physicalPrintQueues = new Map();
const jsonFileOperations = new Map();
const savedJsonValues = new Map();

function closeLedger() {
  try {
    ledger?.close();
  } catch (_) {}
  ledger = null;
}

function shutdown(exitCode = 0) {
  if (shuttingDown) return;
  shuttingDown = true;
  const finish = () => {
    closeLedger();
    process.exit(exitCode);
  };
  server.close(finish);
  setTimeout(finish, 2000).unref();
}

function localLedger() {
  if (ledger) return ledger;
  fsSync.mkdirSync(storageDir, { recursive: true });
  ledger = new DatabaseSync(ledgerFile);
  ledger.exec('PRAGMA synchronous=FULL');
  ledger.exec(`CREATE TABLE IF NOT EXISTS ledger_actions (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    payload TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'queued',
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    synced_at TEXT
  )`);
  ledger.exec(
    'CREATE INDEX IF NOT EXISTS ledger_actions_status_created ON ledger_actions(status, created_at)'
  );
  ledger.exec(`CREATE TABLE IF NOT EXISTS bridge_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  )`);
  ledger.exec(`CREATE TABLE IF NOT EXISTS print_jobs (
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    printer_name TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    completed_at TEXT,
    content_hash TEXT NOT NULL DEFAULT '',
    acknowledged_at TEXT
  )`);
  // Existing Bridge installations keep their local ledger across upgrades.
  // Add the payload fingerprint without requiring staff to delete that data.
  try {
    ledger.exec("ALTER TABLE print_jobs ADD COLUMN content_hash TEXT NOT NULL DEFAULT ''");
  } catch (_) {}
  try {
    ledger.exec('ALTER TABLE print_jobs ADD COLUMN acknowledged_at TEXT');
  } catch (_) {}
  try {
    ledger.exec('ALTER TABLE print_jobs ADD COLUMN lease_expires_at TEXT');
  } catch (_) {}
  return ledger;
}

function expireStalePrintJobs(db = localLedger()) {
  const now = new Date().toISOString();
  return Number(
    db
      .prepare(
        "UPDATE print_jobs SET status='uncertain', completed_at=NULL, acknowledged_at=NULL, lease_expires_at=NULL WHERE status='printing' AND (lease_expires_at IS NULL OR lease_expires_at<=?)"
      )
      .run(now).changes || 0
  );
}

function claimPrintJob(id, kind, printerName, contentHash = '') {
  const safeId = String(id || '')
    .trim()
    .slice(0, 160);
  if (!safeId) return { claim: true, tracked: false };
  const db = localLedger(),
    now = new Date(),
    nowIso = now.toISOString(),
    leaseExpiresAt = new Date(now.getTime() + PRINT_JOB_LEASE_MS).toISOString();
  expireStalePrintJobs(db);
  const existing = db
    .prepare('SELECT status, content_hash, lease_expires_at FROM print_jobs WHERE id=?')
    .get(safeId);
  // The durable job ID identifies the physical slip. Editing a guest name,
  // priority or note must not turn an automatic retry into a second KOT.
  // Intentional corrections/reprints must receive a new explicit job ID.
  if (existing?.status === 'printed')
    return {
      claim: false,
      duplicate: true,
      contentChanged: !!contentHash && existing.content_hash !== contentHash,
    };
  if (existing?.status === 'printing') return { claim: false, pending: true };
  if (existing?.status === 'uncertain') return { claim: false, uncertain: true };
  db.prepare(
    'INSERT INTO print_jobs (id,kind,printer_name,status,created_at,completed_at,content_hash,acknowledged_at,lease_expires_at) VALUES (?,?,?,?,?,NULL,?,NULL,?) ON CONFLICT(id) DO UPDATE SET status=excluded.status, printer_name=excluded.printer_name, created_at=excluded.created_at, completed_at=NULL, content_hash=excluded.content_hash, acknowledged_at=NULL, lease_expires_at=excluded.lease_expires_at'
  ).run(
    safeId,
    kind,
    String(printerName || '').slice(0, 160),
    'printing',
    nowIso,
    String(contentHash || '').slice(0, 64),
    leaseExpiresAt
  );
  return { claim: true, tracked: true };
}
function finishPrintJob(id, result) {
  const safeId = String(id || '')
    .trim()
    .slice(0, 160);
  if (!safeId) return;
  const status = ['printed', 'failed', 'uncertain'].includes(result)
    ? result
    : result
      ? 'printed'
      : 'failed';
  localLedger()
    .prepare(
      'UPDATE print_jobs SET status=?, completed_at=?, acknowledged_at=NULL, lease_expires_at=NULL WHERE id=?'
    )
    .run(status, status === 'printed' ? new Date().toISOString() : null, safeId);
}

async function withPrintJobLease(id, dispatch) {
  const safeId = String(id || '')
    .trim()
    .slice(0, 160);
  let heartbeat = null;
  if (safeId) {
    // A busy receipt queue may have several accepted jobs waiting their turn.
    // Keep this process's ownership alive during the wait as well as dispatch.
    heartbeat = setInterval(
      () => {
        try {
          localLedger()
            .prepare("UPDATE print_jobs SET lease_expires_at=? WHERE id=? AND status='printing'")
            .run(new Date(Date.now() + PRINT_JOB_LEASE_MS).toISOString(), safeId);
        } catch (_) {}
      },
      Math.min(20000, Math.floor(PRINT_JOB_LEASE_MS / 3))
    );
    heartbeat.unref();
  }
  try {
    return await dispatch();
  } finally {
    clearInterval(heartbeat);
  }
}

function ledgerAction(row) {
  let payload = {};
  try {
    payload = JSON.parse(row.payload || '{}');
  } catch (_) {}
  return {
    id: row.id,
    type: row.type,
    payload,
    status: row.status,
    attempts: Number(row.attempts || 0),
    lastError: row.last_error || '',
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    syncedAt: row.synced_at || '',
  };
}

function queueLedgerAction(input) {
  const type = String(input.type || '');
  const id = String(input.id || input.payload?.clientRequestId || '')
    .trim()
    .slice(0, 120);
  const supportedTypes = new Set([
    'counter-order',
    'order-status',
    'order-items',
    'order-table',
    'kitchen-status',
    'availability-update',
    'operations-config',
    'table-areas',
    'settlement',
  ]);
  if (!supportedTypes.has(type) || !id)
    throw new Error('This offline action needs a unique action ID.');
  const payload =
    input.payload && typeof input.payload === 'object' && !Array.isArray(input.payload)
      ? input.payload
      : null;
  if (!payload) throw new Error('Offline action details are required.');
  if (type === 'counter-order' && (!Array.isArray(payload.items) || !payload.items.length))
    throw new Error('An offline order needs at least one item.');
  const encoded = JSON.stringify(payload);
  if (encoded.length > 250000) throw new Error('Offline order is too large to store locally.');
  const now = new Date().toISOString();
  const db = localLedger();
  db.prepare(
    'INSERT INTO ledger_actions (id,type,payload,status,created_at,updated_at) VALUES (?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING'
  ).run(id, type, encoded, 'queued', now, now);
  return ledgerAction(db.prepare('SELECT * FROM ledger_actions WHERE id=?').get(id));
}

function updateLedgerAction(id, status, error = '') {
  const safeId = String(id || '').slice(0, 120);
  if (!safeId || !['queued', 'syncing', 'synced', 'blocked'].includes(status))
    throw new Error('Invalid ledger action update.');
  const now = new Date().toISOString();
  const db = localLedger();
  const existing = db.prepare('SELECT id FROM ledger_actions WHERE id=?').get(safeId);
  if (!existing) throw new Error('Offline action was not found.');
  db.prepare(
    'UPDATE ledger_actions SET status=?, attempts=attempts+1, last_error=?, updated_at=?, synced_at=? WHERE id=?'
  ).run(status, String(error || '').slice(0, 500), now, status === 'synced' ? now : null, safeId);
  return ledgerAction(db.prepare('SELECT * FROM ledger_actions WHERE id=?').get(safeId));
}

function ledgerSummary() {
  expireStalePrintJobs();
  const rows = localLedger()
    .prepare('SELECT status, COUNT(*) AS count FROM ledger_actions GROUP BY status')
    .all();
  const counts = { queued: 0, syncing: 0, blocked: 0, synced: 0 };
  rows.forEach((row) => {
    if (Object.hasOwn(counts, row.status)) counts[row.status] = Number(row.count || 0);
  });
  const jobs = localLedger()
    .prepare('SELECT status, COUNT(*) AS count FROM print_jobs GROUP BY status')
    .all();
  const printJobs = { printing: 0, printed: 0, failed: 0, uncertain: 0 };
  jobs.forEach((row) => {
    if (Object.hasOwn(printJobs, row.status)) printJobs[row.status] = Number(row.count || 0);
  });
  const unresolvedIssues = localLedger()
    .prepare(
      "SELECT COUNT(*) AS count FROM print_jobs WHERE status IN ('failed','uncertain') AND acknowledged_at IS NULL"
    )
    .get();
  const unresolvedFailed = localLedger()
    .prepare(
      "SELECT COUNT(*) AS count FROM print_jobs WHERE status='failed' AND acknowledged_at IS NULL"
    )
    .get();
  return {
    actions: counts,
    pendingActions: counts.queued + counts.syncing,
    blockedActions: counts.blocked,
    printJobs: {
      ...printJobs,
      unresolvedFailed: Number(unresolvedFailed?.count || 0),
      unresolvedIssues: Number(unresolvedIssues?.count || 0),
    },
  };
}

function recentPrintFailures() {
  expireStalePrintJobs();
  return localLedger()
    .prepare(
      "SELECT id, kind, printer_name, status, created_at, completed_at FROM print_jobs WHERE status IN ('failed','uncertain') AND acknowledged_at IS NULL ORDER BY created_at DESC LIMIT 5"
    )
    .all()
    .map((job) => ({
      id: job.id,
      kind: job.kind,
      printerName: job.printer_name,
      status: job.status,
      createdAt: job.created_at,
      completedAt: job.completed_at || '',
    }));
}

function acknowledgePrintJobs(ids) {
  const safeIds = [
    ...new Set(
      (Array.isArray(ids) ? ids : [])
        .map((id) =>
          String(id || '')
            .trim()
            .slice(0, 160)
        )
        .filter(Boolean)
    ),
  ].slice(0, 50);
  if (!safeIds.length) throw new Error('Choose at least one failed print job to mark reviewed.');
  const placeholders = safeIds.map(() => '?').join(','),
    now = new Date().toISOString();
  const result = localLedger()
    .prepare(
      `UPDATE print_jobs SET acknowledged_at=? WHERE status IN ('failed','uncertain') AND acknowledged_at IS NULL AND id IN (${placeholders})`
    )
    .run(now, ...safeIds);
  return Number(result.changes || 0);
}

function run(command, args, timeout = 5000) {
  return new Promise((resolve, reject) => {
    // Apply this centrally to discovery, health recovery and actual printing.
    // No PowerShell child may prompt for input or display a console in service.
    const commandArgs = /(?:^|[\\/])powershell(?:\.exe)?$/i.test(command)
      ? ['-NoLogo', '-NonInteractive', '-WindowStyle', 'Hidden', ...args]
      : args;
    execFile(
      command,
      commandArgs,
      { windowsHide: true, shell: false, timeout },
      (error, stdout) => {
        if (error) reject(error);
        else resolve(String(stdout || ''));
      }
    );
  });
}

async function windowsPrinterSnapshot({ force = false } = {}) {
  if (windowsPrinterSnapshotPromise) return windowsPrinterSnapshotPromise;
  if (
    !force &&
    windowsPrinterSnapshotCache &&
    Date.now() - windowsPrinterSnapshotCache.checkedAt < 5000
  )
    return windowsPrinterSnapshotCache.printers;
  windowsPrinterSnapshotPromise = (async () => {
    // Enumeration during spooler startup can return an empty list or stale
    // Offline flags. Finish recovery before asking Windows for queue details.
    await ensureWindowsSpoolerRunning();
    const script = `$ErrorActionPreference='Stop'; [Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false); $ports=@{}; try { Get-PrinterPort -ErrorAction Stop | ForEach-Object { $ports[$_.Name]=$_ } } catch {}; $queues=@(Get-Printer -ErrorAction Stop); @($queues | ForEach-Object { $port=$ports[$_.PortName]; $protocol=[int]$port.Protocol; $number=if($protocol -eq 2){515}elseif($port.PortNumber){[int]$port.PortNumber}else{9100}; [PSCustomObject]@{ Name=[string]$_.Name; PortName=[string]$_.PortName; Host=[string]$port.PrinterHostAddress; Port=$number; Protocol=$protocol; Status=[string]$_.PrinterStatus } }) | ConvertTo-Json -Compress`;
    let printers;
    try {
      const output = await run('powershell.exe', ['-NoProfile', '-Command', script], 10000);
      const parsed = JSON.parse(output.trim().replace(/^\uFEFF/, '') || '[]');
      printers = (Array.isArray(parsed) ? parsed : [parsed])
        .filter((entry) => entry?.Name)
        .map((entry) => ({
          id: String(entry.Name).trim(),
          name: String(entry.Name).trim(),
          portName: String(entry.PortName || ''),
          host: String(entry.Host || ''),
          port: Number(entry.Port) || 9100,
          protocol: Number(entry.Protocol) || 1,
          status: String(entry.Status || ''),
        }));
    } catch (_) {
      // Windows Home/older drivers may omit PrintManagement. CIM and WMIC
      // still provide the installed queue names; absence of status is unknown.
      printers = [];
    }
    if (!printers.length) {
      let discovered = false;
      for (const [command, args] of [
        [
          'powershell.exe',
          [
            '-NoProfile',
            '-Command',
            '[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false); Get-CimInstance -ClassName Win32_Printer -ErrorAction Stop | Select-Object -ExpandProperty Name',
          ],
        ],
        ['wmic.exe', ['printer', 'get', 'name', '/value']],
      ]) {
        try {
          const output = await run(command, args);
          discovered = true;
          printers = formatPrinters(
            output.split(/\r?\n/).map((line) => line.replace(/^Name=/i, ''))
          );
          if (printers.length) break;
        } catch (_) {}
      }
      if (!discovered)
        throw new Error(
          'Windows could not read installed printers. Confirm the Print Spooler is running and install the printer manufacturer’s Windows driver.'
        );
    }
    windowsPrinterSnapshotCache = { checkedAt: Date.now(), printers };
    return printers;
  })().finally(() => {
    windowsPrinterSnapshotPromise = null;
  });
  return windowsPrinterSnapshotPromise;
}

async function installedPrinters() {
  let output = '';
  if (process.platform === 'win32') return windowsPrinterSnapshot();
  if (process.platform === 'darwin') {
    try {
      output = await run('lpstat', ['-p']);
    } catch (_) {
      throw new Error(
        'macOS printing is unavailable. Add the printer in System Settings > Printers & Scanners, then install its AirPrint or manufacturer driver.'
      );
    }
    return formatPrinters(
      output.split(/\r?\n/).map((line) => {
        const match = line.match(/^printer\s+([^\s]+)/i);
        return match ? match[1] : '';
      })
    );
  } else {
    try {
      output = await run('lpstat', ['-p']);
    } catch (_) {
      throw new Error(
        'CUPS printer discovery is unavailable. Install and configure CUPS and the printer driver.'
      );
    }
    return formatPrinters(
      output.split(/\r?\n/).map((line) => {
        const match = line.match(/^printer\s+([^\s]+)/i);
        return match ? match[1] : '';
      })
    );
  }
}

async function ensureWindowsSpoolerRunning({ force = false } = {}) {
  if (process.platform !== 'win32') return { attempted: false, recovered: false };
  const now = Date.now();
  if (!force && now - windowsSpoolerCheck.checkedAt < 30000)
    return { ...windowsSpoolerCheck.result, cached: true };
  if (windowsSpoolerCheckPromise) return windowsSpoolerCheckPromise;
  windowsSpoolerCheckPromise = (async () => {
    let result;
    try {
      const output = await run(
        'powershell.exe',
        [
          '-NoProfile',
          '-Command',
          "$actions = @(); $service = Get-Service -Name Spooler -ErrorAction Stop; if ($service.Status -ne 'Running') { Start-Service -Name Spooler -ErrorAction Stop; $service.WaitForStatus('Running', [TimeSpan]::FromSeconds(5)); $actions += 'spooler' }; $paused = @(Get-Printer -ErrorAction SilentlyContinue | Where-Object { \"$($_.PrinterStatus)\" -match 'Paused|Stopped' }); foreach ($printer in $paused) { try { $escaped = $printer.Name.Replace(\"'\", \"''\"); $queue = Get-CimInstance -ClassName Win32_Printer -Filter \"Name='$escaped'\" -ErrorAction Stop; Invoke-CimMethod -InputObject $queue -MethodName Resume -ErrorAction Stop | Out-Null; $actions += 'queue' } catch {} }; if ($actions.Count) { $actions -join ',' } else { 'running' }",
        ],
        8000
      );
      const actions = output
        .trim()
        .toLowerCase()
        .split(',')
        .filter((action) => action === 'spooler' || action === 'queue');
      result = {
        attempted: true,
        recovered: actions.length > 0,
        recoveredSpooler: actions.includes('spooler'),
        resumedQueues: actions.filter((action) => action === 'queue').length,
        running: true,
      };
    } catch (error) {
      // Printer discovery below remains authoritative. Older installations may
      // still run the Bridge without an elevated token, so expose the recovery
      // failure without preventing a healthy queue from being used.
      result = {
        attempted: true,
        recovered: false,
        running: false,
        error: String(error.message || 'Windows could not start the Print Spooler.').slice(0, 300),
      };
    }
    windowsSpoolerCheck = { checkedAt: Date.now(), result };
    return result;
  })().finally(() => {
    windowsSpoolerCheckPromise = null;
  });
  return windowsSpoolerCheckPromise;
}

async function unavailablePrinterNames() {
  try {
    if (process.platform === 'win32') {
      const printers = await windowsPrinterSnapshot();
      return new Set(
        printers
          .filter((printer) =>
            /Offline|Error|PaperOut|PaperJam|NotAvailable|DoorOpen|UserIntervention/i.test(
              printer.status || ''
            )
          )
          .map((printer) => printer.name)
      );
    }
    const output = await run('lpstat', ['-p']);
    return new Set(
      output
        .split(/\r?\n/)
        .filter((line) => /^printer\s+\S+\s+is\s+disabled/i.test(line))
        .map((line) => line.match(/^printer\s+([^\s]+)/i)?.[1] || '')
        .filter(Boolean)
    );
  } catch (_) {
    // Queue-state discovery is an extra readiness signal. Printer discovery and
    // actual print attempts remain authoritative when the OS omits this data.
    return new Set();
  }
}

async function networkPrinterEndpoints() {
  try {
    if (process.platform === 'win32') {
      const printers = await windowsPrinterSnapshot();
      return new Map(
        printers
          .filter((printer) => printer.host)
          .map((printer) => [
            printer.name,
            { host: printer.host, port: printer.port, protocol: printer.protocol },
          ])
      );
    }
    const output = await run('lpstat', ['-v']);
    return new Map(
      output
        .split(/\r?\n/)
        .map((line) => {
          const match = line.match(
            /^device for\s+([^:]+):\s+(?:socket|ipp|ipps):\/\/([^/:\s]+)(?::(\d+))?/i
          );
          return match
            ? [
                match[1],
                { host: match[2], port: Number(match[3]) || (line.includes('ipp') ? 631 : 9100) },
              ]
            : null;
        })
        .filter(Boolean)
    );
  } catch (_) {
    return new Map();
  }
}

function tcpEndpointReachable(host, port, timeout = 1500) {
  // The same physical printer may expose separate Bill and KOT queues. Share
  // its probe instead of opening simultaneous connections to a small receipt
  // printer's single network accept slot.
  const key = `${String(host).toLowerCase()}:${Number(port) || 9100}`;
  if (networkProbePromises.has(key)) return networkProbePromises.get(key);
  const probe = probeTcpEndpoint(host, port, timeout).finally(() =>
    networkProbePromises.delete(key)
  );
  networkProbePromises.set(key, probe);
  return probe;
}

async function probeTcpEndpoint(host, port, timeout) {
  // Some Windows printer drivers expose a working Standard TCP/IP port while
  // Node's socket probe is blocked or times out. Use the Windows networking
  // stack directly so the first probe does not interfere with the printer's
  // limited connection queue.
  if (process.platform === 'win32') {
    const safePort = Number(port) || 9100;
    const cacheKey = `${String(host).toLowerCase()}:${safePort}`;
    const cached = networkReachability.get(cacheKey);
    if (cached?.reachable && Date.now() - cached.checkedAt < 120000) return true;
    const safeHost = String(host).replace(/'/g, "''");
    const safeTimeout = Math.max(timeout, 750);
    let reachable = false;
    for (let attempt = 0; attempt < 1 && !reachable; attempt += 1) {
      try {
        const output = await run(
          'powershell.exe',
          [
            '-NoProfile',
            '-Command',
            `$hostName='${safeHost}'; $port=${safePort}; $timeout=${safeTimeout}; $client=[System.Net.Sockets.TcpClient]::new(); try { $task=$client.ConnectAsync($hostName,$port); if($task.Wait($timeout) -and $client.Connected){"reachable"}else{"unreachable"} } catch { "unreachable" } finally { $client.Dispose() }`,
          ],
          safeTimeout + 10000
        );
        reachable = output.trim() === 'reachable';
      } catch (_) {}
    }
    // RAW printer ports can briefly refuse a health connection after a job or
    // another probe. A recent successful connection remains authoritative.
    if (!reachable && cached?.reachable && Date.now() - cached.checkedAt < 300000) return true;
    networkReachability.set(cacheKey, { reachable, checkedAt: Date.now() });
    return reachable;
  }

  return new Promise((resolve) => {
    const socket = net.createConnection({ host, port: Number(port) || 9100 });
    let completed = false;
    const finish = (reachable) => {
      if (completed) return;
      completed = true;
      socket.destroy();
      resolve(reachable);
    };
    socket.setTimeout(timeout, () => finish(false));
    socket.once('connect', () => finish(true));
    socket.once('error', () => finish(false));
  });
}

function formatPrinters(names) {
  return [...new Set(names.map((name) => name.trim()).filter(Boolean))]
    .sort((a, b) => a.localeCompare(b))
    .map((name) => ({ id: name, name }));
}

function durableJsonKey(file) {
  if (file === workstationFile) return 'workstation';
  if (file === configFile) return 'printer-config';
  return '';
}

function validStoredJson(file, value) {
  if (file === workstationFile)
    return !!value && typeof value.id === 'string' && /^[a-zA-Z0-9_-]{1,80}$/.test(value.id);
  if (file === configFile)
    return !!value && Array.isArray(value.printers) && Array.isArray(value.routes);
  return true;
}

function withJsonFileOperation(file, operation) {
  const previous = jsonFileOperations.get(file) || Promise.resolve();
  const next = previous.catch(() => {}).then(operation);
  jsonFileOperations.set(file, next);
  return next.finally(() => {
    if (jsonFileOperations.get(file) === next) jsonFileOperations.delete(file);
  });
}

async function atomicJsonCopy(file, value) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  const temporary = `${file}.${process.pid}.${crypto.randomUUID()}.tmp`;
  let handle;
  try {
    handle = await fs.open(temporary, 'wx', 0o600);
    await handle.writeFile(JSON.stringify(value, null, 2), 'utf8');
    await handle.sync();
    await handle.close();
    handle = null;
    // Antivirus and Windows spooler activity may briefly lock a state file.
    // Retry the atomic replacement without deleting the known-good copy.
    for (let attempt = 0; ; attempt += 1) {
      try {
        await fs.rename(temporary, file);
        break;
      } catch (error) {
        if (attempt >= 4 || !['EBUSY', 'EPERM', 'EACCES'].includes(error.code)) throw error;
        await new Promise((resolve) => setTimeout(resolve, 40 * 2 ** attempt));
      }
    }
    // POSIX requires the directory entry to be flushed as well. Windows does
    // not expose a directory fsync through Node, but the file itself is flushed.
    if (process.platform !== 'win32') {
      let directory;
      try {
        directory = await fs.open(path.dirname(file), 'r');
        await directory.sync();
      } finally {
        await directory?.close();
      }
    }
  } finally {
    await handle?.close();
    await fs.unlink(temporary).catch(() => {});
  }
}

async function readJsonUnlocked(file, fallback) {
  const key = durableJsonKey(file);
  if (!key) {
    try {
      return JSON.parse(await fs.readFile(file, 'utf8'));
    } catch (error) {
      if (error.code === 'ENOENT') return fallback;
      throw error;
    }
  }
  const copies = [];
  const failures = [];
  for (const copyFile of [file, `${file}.bak`]) {
    try {
      const value = JSON.parse(await fs.readFile(copyFile, 'utf8'));
      if (!validStoredJson(file, value)) throw new Error('Saved printer state is incomplete.');
      copies.push({ source: copyFile, value });
    } catch (error) {
      failures.push(error);
    }
  }
  let metadata;
  try {
    const row = localLedger().prepare('SELECT value FROM bridge_settings WHERE key=?').get(key);
    if (row) {
      const value = JSON.parse(row.value);
      if (!validStoredJson(file, value))
        throw new Error('Saved printer ledger state is incomplete.');
      metadata = value;
      copies.push({ source: 'ledger', value });
    }
  } catch (error) {
    failures.push(error);
  }
  // The SQLite identity is a third durable copy. It must win if an accidental
  // edit introduces another valid-looking workstation ID into a JSON file.
  let value = file === workstationFile && metadata ? metadata : copies[0]?.value;
  if (file === configFile && copies.length)
    value = copies.reduce(
      (latest, copy) =>
        String(copy.value.savedAt || '') > String(latest.savedAt || '') ? copy.value : latest,
      copies[0].value
    );
  if (!value) value = savedJsonValues.get(file);
  if (!value) {
    const failure = failures.find((error) => error.code !== 'ENOENT');
    if (failure) throw failure;
    return fallback;
  }
  savedJsonValues.set(file, value);
  const encoded = JSON.stringify(value);
  // Heal a missing/truncated copy in the background path. A temporary disk
  // lock never changes this machine's ID or erases an established pairing.
  for (const copyFile of [file, `${file}.bak`]) {
    const copy = copies.find((candidate) => candidate.source === copyFile);
    if (!copy || JSON.stringify(copy.value) !== encoded)
      await atomicJsonCopy(copyFile, value).catch(() => {});
  }
  if (!metadata || JSON.stringify(metadata) !== encoded) {
    try {
      localLedger()
        .prepare(
          'INSERT INTO bridge_settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value'
        )
        .run(key, encoded);
    } catch (_) {}
  }
  return value;
}

function readJson(file, fallback) {
  return withJsonFileOperation(file, () => readJsonUnlocked(file, fallback));
}

async function writeJsonUnlocked(file, value) {
  const key = durableJsonKey(file);
  let persisted = false;
  let failure;
  if (key) {
    try {
      localLedger()
        .prepare(
          'INSERT INTO bridge_settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value'
        )
        .run(key, JSON.stringify(value));
      persisted = true;
    } catch (error) {
      failure = error;
    }
  }
  for (const copyFile of key ? [file, `${file}.bak`] : [file]) {
    try {
      await atomicJsonCopy(copyFile, value);
      persisted = true;
    } catch (error) {
      failure = error;
    }
  }
  if (!persisted)
    throw failure || new Error('Unable to retain printer configuration on this computer.');
  if (key) savedJsonValues.set(file, value);
}

function writeJson(file, value) {
  return withJsonFileOperation(file, () => writeJsonUnlocked(file, value));
}

function configRevision(value) {
  const revision = String(value || '').trim();
  return /^\d{1,30}$/.test(revision) ? revision : '';
}

async function saveLocalPrinterConfig(payload) {
  const config = payload?.config;
  const background = payload?.background === true;
  if (!config || !Array.isArray(config.printers) || (background && !Array.isArray(config.routes)))
    throw new Error('A complete printer configuration is required before updating saved pairing.');
  const identity = await workstationIdentity();
  // A driver/spooler outage cannot delete remembered bindings. Already-paired
  // devices are assigned by durable workstation ID, independent of discovery.
  const installed = await installedPrinters().catch(() => []);
  return withJsonFileOperation(configFile, async () => {
    const saved = await readJsonUnlocked(configFile, { printers: [], routes: [] });
    const installedNames = new Set(installed.map((printer) => String(printer.name).trim()));
    const incomingRevision = configRevision(payload.revision || config.configRevision);
    const savedRevision = configRevision(saved.sourceRevision || saved.configRevision);
    const hasNewerRevision =
      !!incomingRevision && BigInt(incomingRevision) > BigInt(savedRevision || '0');
    const hasEstablishedConfig = !!saved.savedAt || !!savedRevision || saved.printers.length > 0 || saved.routes.length > 0;
    const preserveSaved = background && hasEstablishedConfig && !hasNewerRevision;
    const savedPrinters = new Map(saved.printers.map((printer) => [String(printer.id), printer]));
    const incomingPrinters = config.printers.filter(
      (printer) => printer && typeof printer === 'object'
    );
    const candidates = preserveSaved ? saved.printers : incomingPrinters;
    const printers = candidates
      .slice(0, 250)
      .map((printer) => {
        const remembered = savedPrinters.get(String(printer.id));
        if (
          !background ||
          !remembered ||
          (printer.workstationId && printer.workstationId !== identity.id)
        )
          return printer;
        return {
          ...printer,
          deviceId: printer.deviceId || remembered.deviceId,
          deviceName: printer.deviceName || remembered.deviceName,
          workstationId: printer.workstationId || remembered.workstationId,
          workstationName: printer.workstationName || remembered.workstationName,
        };
      })
      .filter((printer) => printerMatchesWorkstation(printer, identity, installedNames, installed))
      .map((printer) => {
        const capabilities = printerCapabilities(printer);
        return {
          ...printer,
          id: String(printer.id || '').slice(0, 60),
          name: String(printer.name || '')
            .trim()
            .slice(0, 60),
          capabilities,
          type: capabilities[0] || (printer.type === 'bill' ? 'bill' : 'kot'),
          deviceId: String(printer.deviceId || '').slice(0, 160),
          deviceName: (
            resolveSystemPrinter(printer.deviceName, installed)?.name ||
            String(printer.deviceName || '')
          ).slice(0, 160),
          workstationId: identity.id,
          workstationName: identity.name,
        };
      })
      .filter((printer) => printer.id && printer.name);
    const printerIds = new Set(printers.map((printer) => printer.id));
    const incomingRoutes = (Array.isArray(config.routes) ? config.routes : []).filter(
      (route) => route && typeof route === 'object'
    );
    const routeCandidates = preserveSaved ? saved.routes : incomingRoutes;
    const routes = routeCandidates
      .slice(0, 2000)
      .map((route) => ({
        id: String(route.id || '').slice(0, 60),
        printerId: String(route.printerId || '').slice(0, 60),
        category: String(route.category || '')
          .trim()
          .slice(0, 100),
        itemName: String(route.itemName || '')
          .trim()
          .slice(0, 160),
        portion: String(route.portion || '')
          .trim()
          .slice(0, 40),
      }))
      .filter((route) => route.id && printerIds.has(route.printerId) && route.category);
    const revision = hasNewerRevision ? incomingRevision : savedRevision || incomingRevision;
    const safeConfig = {
      printers,
      routes,
      ...(Array.isArray(config.tableAreas) ? { tableAreas: config.tableAreas } :
        Array.isArray(saved.tableAreas) ? { tableAreas: saved.tableAreas } : {}),
      workstation: identity,
      savedAt: new Date(
        Math.max(Date.now(), (Date.parse(saved.savedAt || '') || 0) + 1)
      ).toISOString(),
      ...(revision ? { configRevision: revision, sourceRevision: revision } : {}),
    };
    await writeJsonUnlocked(configFile, safeConfig);
    return {
      ok: true,
      savedAt: safeConfig.savedAt,
      configRevision: revision,
      preserved: preserveSaved,
      config: safeConfig,
    };
  });
}

function workstationIdentity() {
  if (workstationIdentityPromise) return workstationIdentityPromise;
  workstationIdentityPromise = (async () => {
    let saved = await readJson(workstationFile, null).catch(async (error) => {
      const config = await readJson(configFile, null);
      if (validStoredJson(workstationFile, config?.workstation)) return config.workstation;
      throw error;
    });
    if (!saved) {
      const config = await readJson(configFile, null);
      if (validStoredJson(workstationFile, config?.workstation)) saved = config.workstation;
    }
    if (saved?.id) {
      // Seed identity backup/ledger for installations upgrading from a single
      // JSON file; setup updates never manufacture a replacement identity.
      await writeJson(workstationFile, saved);
      return {
        id: String(saved.id)
          .replace(/[^a-zA-Z0-9_-]/g, '')
          .slice(0, 80),
        name: String(saved.name || os.hostname() || 'Restaurant computer')
          .trim()
          .slice(0, 120),
        platform: process.platform,
        createdAt: String(saved.createdAt || ''),
      };
    }
    const identity = {
      id: `ws_${crypto.randomUUID().replace(/-/g, '')}`,
      name: String(os.hostname() || 'Restaurant computer')
        .trim()
        .slice(0, 120),
      platform: process.platform,
      createdAt: new Date().toISOString(),
    };
    await writeJson(workstationFile, identity);
    return identity;
  })().catch((error) => {
    workstationIdentityPromise = null;
    throw error;
  });
  return workstationIdentityPromise;
}

function printerMatchesWorkstation(printer, identity, installedNames, printers = []) {
  const assigned = String(printer?.workstationId || '').trim();
  if (assigned) return assigned === identity.id;
  // Existing installations did not have a workstation ID. Adopt a legacy
  // queue only when the identically named OS printer exists on this computer.
  return (
    installedNames.has(String(printer?.deviceName || '').trim()) ||
    !!resolveSystemPrinter(printer?.deviceName, printers)
  );
}

async function assertRequestedWorkstation(payload) {
  const requested = String(payload?.workstationId || '').trim();
  if (!requested) return;
  const identity = await workstationIdentity();
  if (requested !== identity.id) {
    const error = new Error('This print job belongs to a different restaurant computer.');
    error.code = 'WORKSTATION_MISMATCH';
    throw error;
  }
}

async function resolvePrintQueue(printerName) {
  if (!printerName) throw new Error('Assign an installed system printer before printing.');
  const printers = await installedPrinters();
  const queue = resolveSystemPrinter(printerName, printers);
  if (!queue) {
    const error = new Error(
      `${printerName} is not installed on this computer. Choose its Windows printer queue in Operations.`
    );
    error.code = 'PRINTER_NOT_INSTALLED';
    throw error;
  }
  return queue.name;
}

function printText(printerName, text, settings = {}) {
  // Many receipt drivers cannot accept overlapping GDI jobs reliably. Keep one
  // physical dispatch at a time per queue while independent kitchens run in parallel.
  const previous = physicalPrintQueues.get(printerName) || Promise.resolve();
  const next = previous.catch(() => {}).then(() => dispatchPrintText(printerName, text, settings));
  physicalPrintQueues.set(printerName, next);
  return next.finally(() => {
    if (physicalPrintQueues.get(printerName) === next) physicalPrintQueues.delete(printerName);
  });
}

async function dispatchPrintText(printerName, text, settings = {}) {
  // The background monitor repairs the spooler. Do not hold a print request
  // behind printer enumeration or a PowerShell health check.
  if (process.platform === 'win32') {
    if (!windowsSpoolerCheck.result.running) await ensureWindowsSpoolerRunning({ force: true });
    else if (Date.now() - windowsSpoolerCheck.checkedAt >= 30000)
      void ensureWindowsSpoolerRunning();
  }
  const file = path.join(os.tmpdir(), `red-lantern-kot-${crypto.randomUUID()}.txt`);
  await fs.writeFile(file, text, 'utf8');
  try {
    if (process.platform === 'win32') {
      const quote = (value) => String(value).replace(/'/g, "''");
      const paperWidth = Number(settings.paperWidth) === 58 ? 58 : 80;
      const fontFamily = [
        'Arial',
        'Calibri',
        'Verdana',
        'Tahoma',
        'Trebuchet MS',
        'Georgia',
        'Times New Roman',
        'Courier New',
        'Consolas',
        'Lucida Console',
      ].includes(String(settings.fontFamily))
        ? String(settings.fontFamily).replace(/'/g, "''")
        : 'Arial';
      const bodyFontSize = Math.max(8, Math.min(13, Number(settings.fontSize) || 10));
      const headerFontSize = Math.max(12, Math.min(18, Number(settings.headerFontSize) || 15));
      const headerStyle = settings.headerBold === false ? 'Regular' : 'Bold';
      const footerStyle = settings.footerBold ? 'Bold' : 'Regular';
      const layout = (value, min, max, fallback) => {
        const parsed = Number(value);
        return Math.max(min, Math.min(max, Number.isFinite(parsed) ? parsed : fallback));
      };
      // 309 hundredths of an inch is 78.5 mm: the measured printable span of
      // the 80 mm reference receipt.  The driver still owns the actual paper
      // form, so this safely shrinks when a printer has a narrower print area.
      // Never enlarge a saved printable width. Some 80 mm drivers expose only
      // 250 units of usable width; forcing 300 makes the right columns print
      // outside the paper and causes the clipping seen on the receipt.
      const isKot = text.includes('__KOTITEM__'),
        configuredMainWidth = layout(settings.billingMainWidth, 160, 400, 309),
        // KOTs must use the selected paper form's complete printable width.
        // Billing layout controls are deliberately independent: a narrower
        // bill table must never make kitchen tickets waste paper or wrap early.
        mainWidth = isKot ? Number.MAX_SAFE_INTEGER : configuredMainWidth,
        leftMargin = layout(settings.billingOuterLeft, 0, 40, 0),
        rightMargin = layout(settings.billingOuterRight, 0, 40, 0),
        topMargin = layout(settings.billingOuterTop, 0, 40, 0),
        bottomMargin = layout(settings.billingOuterBottom, 0, 40, 0);
      const restaurantFontSize = layout(settings.restaurantNameFontSize, 8, 24, 14),
        headerFooterFontSize = layout(settings.headerFooterFontSize, 8, 20, 13),
        dateBillFontSize = layout(settings.dateBillFontSize, 8, 20, 13),
        itemFontSize = layout(settings.itemListingFontSize, 8, 10, 10),
        totalFontSize = layout(settings.grandTotalFontSize, 10, 11, 11),
        kotHeaderFontSize = layout(settings.kotHeaderFontSize, 8, 24, 12),
        kotTitleFontSize = layout(settings.kotTitleFontSize, 10, 26, 15),
        kotMetaFontSize = layout(settings.kotMetaFontSize, 8, 20, 10),
        kotItemFontSize = layout(settings.kotItemFontSize, 8, 22, 12),
        kotFooterFontSize = layout(settings.kotFooterFontSize, 8, 20, 10),
        itemGap = layout(settings.itemRowGap, 0, 20, 3),
        separatorGap = layout(settings.separatorGap, 0, 20, 3),
        separatorThickness = layout(settings.separatorThickness, 1, 4, 1),
        grandTotalWidth = layout(settings.grandTotalContentWidth, 120, 400, 261),
        itemMinHeight = layout(settings.billingItemBoxHeight, 0, 40, 0);
      const script = `Add-Type -AssemblyName System.Drawing
$lines = Get-Content -LiteralPath '${quote(file)}' -Encoding UTF8
$doc = New-Object System.Drawing.Printing.PrintDocument
$doc.PrinterSettings.PrinterName = '${quote(printerName)}'
if (-not $doc.PrinterSettings.IsValid) { throw 'The selected Windows printer is no longer available.' }
# Windows drivers report paper sizes in hundredths of an inch. Select the form
# closest to the width saved in Operations, rather than relying on a specific
# driver's paper-name convention or a hard-coded list of thermal-paper forms.
$requestedWidth = [int][Math]::Round(${paperWidth} / 25.4 * 100)
$maximumDifference = [int][Math]::Round($requestedWidth * 0.2)
$thermalPaper = @($doc.PrinterSettings.PaperSizes |
  ForEach-Object { [pscustomobject]@{ Paper = $_; Difference = [Math]::Abs($_.Width - $requestedWidth) } } |
  Where-Object { $_.Difference -le $maximumDifference } |
  Sort-Object Difference |
  Select-Object -First 1)
if ($thermalPaper.Count) { $doc.DefaultPageSettings.PaperSize = $thermalPaper[0].Paper }
$doc.DefaultPageSettings.Margins = New-Object System.Drawing.Printing.Margins(${leftMargin}, ${rightMargin}, ${topMargin}, ${bottomMargin})
$doc.PrintController = New-Object System.Drawing.Printing.StandardPrintController
$doc.add_PrintPage({ param($sender, $event)
  $g = $event.Graphics; $safeHorizontalInset = if (${isKot ? '$true' : '$false'}) { [Math]::Ceiling($event.MarginBounds.Width * 0.04) } else { 0 }; $contentLeft = $event.MarginBounds.Left + $safeHorizontalInset; $width = [Math]::Max(120, [Math]::Min($event.MarginBounds.Width - ($safeHorizontalInset * 2), ${mainWidth}) - 8); $y = $event.MarginBounds.Top
  $bodySize = ${bodyFontSize}; $sectionStarts = @{}
  foreach ($line in $lines) {
    $displayLine = $line; $style = [System.Drawing.FontStyle]::Regular; $size = $bodySize; $alignment = [System.Drawing.StringAlignment]::Center; $fontName = ''
    if ($line.StartsWith('__SECTIONSTART__')) { $sectionStarts[$line.Substring(16)] = $y; continue }
    if ($line.StartsWith('__SECTIONEND__')) { $parts = $line.Substring(14).Split('|', 2); if ($parts.Count -eq 2 -and $sectionStarts.ContainsKey($parts[0])) { $y = [Math]::Max($y, $sectionStarts[$parts[0]] + [Math]::Max(0, [int]$parts[1])) }; continue }
    if ($line.StartsWith('__KOTRULE__')) {
      $pen = New-Object System.Drawing.Pen([System.Drawing.Color]::Black, 3)
      $g.DrawLine($pen, $contentLeft, $y + 3, $contentLeft + $width, $y + 3)
      $pen.Dispose(); $y += 9; continue
    }
    if ($line.StartsWith('__SEPARATOR__')) {
      $pen = New-Object System.Drawing.Pen([System.Drawing.Color]::Black, ${separatorThickness})
      $g.DrawLine($pen, $contentLeft, $y + 2, $contentLeft + $width, $y + 2)
      $pen.Dispose(); $y += 4 + ${separatorGap}; continue
    }
    if ($line.StartsWith('__KOTITEM__')) {
      # Draw the complete line in one GDI operation.  The former token-by-token
      # renderer was driver-sensitive and could print only the first character
      # of an item on some thermal printers.
      $plainItem = $line.Substring(11).Replace('[[', '').Replace(']]', '')
      $font = New-Object System.Drawing.Font('${fontFamily}', ${kotItemFontSize}, [System.Drawing.FontStyle]::Bold)
      $format = New-Object System.Drawing.StringFormat; $format.Alignment = [System.Drawing.StringAlignment]::Near; $format.Trimming = [System.Drawing.StringTrimming]::Word
      $parts = $plainItem.Split('|', 2); $qty = if ($parts.Count -gt 1) { $parts[0] } else { '' }; $label = if ($parts.Count -gt 1) { $parts[1] } else { $plainItem }
      $qtyWidth = [Math]::Max(28, $g.MeasureString('Qty.', $font).Width + 5); $itemLeft = $contentLeft + $qtyWidth; $itemWidth = [Math]::Max(80, $width - $qtyWidth)
      if ($qty) { $g.DrawString($qty, $font, [System.Drawing.Brushes]::Black, [single]$contentLeft, [single]$y) }
      $bounds = New-Object System.Drawing.RectangleF([single]$itemLeft, [single]$y, [single]$itemWidth, 400)
      $height = $g.MeasureString($label, $font, $itemWidth, $format).Height
      $g.DrawString($label, $font, [System.Drawing.Brushes]::Black, $bounds, $format)
      $y += [Math]::Ceiling($height) + ${itemGap}; $font.Dispose(); $format.Dispose(); continue
    }
    if ($line.StartsWith('__KOTMODIFIER__')) {
      $modifier = $line.Substring(15); $font = New-Object System.Drawing.Font('${fontFamily}', [Math]::Max(8, ${kotItemFontSize} - 1), [System.Drawing.FontStyle]::Bold)
      $modifierLeft = $contentLeft + [Math]::Max(28, $g.MeasureString('Qty.', $font).Width + 5); $modifierWidth = [Math]::Max(80, $width - ($modifierLeft - $contentLeft))
      $format = New-Object System.Drawing.StringFormat; $format.Alignment = [System.Drawing.StringAlignment]::Near; $format.Trimming = [System.Drawing.StringTrimming]::Word
      $bounds = New-Object System.Drawing.RectangleF([single]$modifierLeft, [single]$y, [single]$modifierWidth, 400); $height = $g.MeasureString($modifier, $font, $modifierWidth, $format).Height
      $g.DrawString($modifier, $font, [System.Drawing.Brushes]::Black, $bounds, $format)
      $y += [Math]::Ceiling($height) + 1; $font.Dispose(); $format.Dispose(); continue
    }
    if ($line.StartsWith('__ITEMHEAD__') -or $line.StartsWith('__ITEM__')) {
      $cells = $line.Substring($(if ($line.StartsWith('__ITEMHEAD__')) { 12 } else { 8 })).Split('|')
      $isHead = $line.StartsWith('__ITEMHEAD__')
      $style = if ($isHead) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular }
      $size = ${itemFontSize}
      $font = New-Object System.Drawing.Font('${fontFamily}', $size, $style)
      $serialWidth = [Math]::Floor(${layout(settings.serialColumnWidth, 0, 40, 10)}); $columnGap = 4; $qtyWidth = [Math]::Max(28, [Math]::Floor(${layout(settings.quantityColumnWidth, 8, 60, 20)})); $priceWidth = [Math]::Max(46, [Math]::Floor(${layout(settings.priceColumnWidth, 15, 100, 40)})); $amountWidth = [Math]::Max(60, [Math]::Floor(${layout(settings.amountColumnWidth, 15, 120, 55)})); $itemMinWidth = [Math]::Floor(${layout(settings.itemNameMinWidth, 50, 220, 110)}); $maxColumns = [Math]::Max(40, $width - $itemMinWidth); $columnTotal = $qtyWidth + $priceWidth + $amountWidth + ($columnGap * 2)
      if ($columnTotal -gt $maxColumns) { $scale = $maxColumns / $columnTotal; $qtyWidth = [Math]::Max(25, [Math]::Floor($qtyWidth * $scale)); $priceWidth = [Math]::Max(40, [Math]::Floor($priceWidth * $scale)); $amountWidth = [Math]::Max(52, $maxColumns - $qtyWidth - $priceWidth - ($columnGap * 2)) }
      $labelWidth = [Math]::Max(50, $width - $qtyWidth - $priceWidth - $amountWidth - ($columnGap * 2))
      $left = $contentLeft
      $near = New-Object System.Drawing.StringFormat; $near.Alignment = [System.Drawing.StringAlignment]::Near
      $right = New-Object System.Drawing.StringFormat; $right.Alignment = [System.Drawing.StringAlignment]::Far
      $label = if ($cells.Count -gt 0) { $cells[0] } else { '' }; $serial = ''
      if (-not $isHead -and $label -match '^(\\d+\\.\\s+)(.*)$') { $serial = $matches[1]; $label = $matches[2] }
      $contentLeft = $left; $contentWidth = $labelWidth
      if ($serial) { $g.DrawString($serial, $font, [System.Drawing.Brushes]::Black, [single]$left, [single]$y); $contentLeft += $serialWidth; $contentWidth = [Math]::Max(50, $labelWidth - $serialWidth) }
      $labelLines = New-Object System.Collections.Generic.List[string]; $pending = ''
      foreach ($word in $label.Split(' ')) { $candidate = if ($pending) { "$pending $word" } else { $word }; if ($pending -and $g.MeasureString($candidate, $font).Width -gt $contentWidth) { $labelLines.Add($pending); $pending = $word } else { $pending = $candidate } }
      if ($pending) { $labelLines.Add($pending) }; if ($labelLines.Count -eq 0) { $labelLines.Add('') }
      $lineHeight = [Math]::Ceiling($g.MeasureString('Ag', $font).Height); $rowHeight = [Math]::Max([Math]::Max($labelLines.Count * $lineHeight, $lineHeight), ${itemMinHeight})
      for ($labelIndex = 0; $labelIndex -lt $labelLines.Count; $labelIndex++) { $g.DrawString($labelLines[$labelIndex], $font, [System.Drawing.Brushes]::Black, [single]$contentLeft, [single]($y + ($labelIndex * $lineHeight))) }
      $qtyText = if ($cells.Count -gt 1) { $cells[1] } else { '' }; $priceText = if ($cells.Count -gt 2) { $cells[2] } else { '' }; $amountText = if ($cells.Count -gt 3) { $cells[3] } else { '' }
      $qtyX = $left + $labelWidth + $qtyWidth - $g.MeasureString($qtyText, $font).Width; $priceX = $left + $labelWidth + $qtyWidth + $columnGap + $priceWidth - $g.MeasureString($priceText, $font).Width; $amountX = $left + $labelWidth + $qtyWidth + $columnGap + $priceWidth + $columnGap + $amountWidth - $g.MeasureString($amountText, $font).Width
      $g.DrawString($qtyText, $font, [System.Drawing.Brushes]::Black, [single]$qtyX, [single]$y)
      $g.DrawString($priceText, $font, [System.Drawing.Brushes]::Black, [single]$priceX, [single]$y)
      $g.DrawString($amountText, $font, [System.Drawing.Brushes]::Black, [single]$amountX, [single]$y)
      $y += [Math]::Ceiling($rowHeight) + $(if ($isHead) { 5 } else { ${itemGap} }); $font.Dispose(); $near.Dispose(); $right.Dispose(); continue
    }
    if ($line.StartsWith('__COMPACTHEAD__') -or $line.StartsWith('__COMPACTITEM__')) {
      $isHead = $line.StartsWith('__COMPACTHEAD__')
      $prefixLength = if ($isHead) { 15 } else { 15 }
      $cells = $line.Substring($prefixLength).Split('|')
      $style = if ($isHead) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular }
      $font = New-Object System.Drawing.Font('Consolas', [Math]::Min(${itemFontSize}, 9), $style)
      $qtyWidth = 23; $priceWidth = 47; $amountWidth = 52; $labelWidth = [Math]::Max(68, $width - $qtyWidth - $priceWidth - $amountWidth)
      $left = $contentLeft; $near = New-Object System.Drawing.StringFormat; $near.Alignment = [System.Drawing.StringAlignment]::Near; $right = New-Object System.Drawing.StringFormat; $right.Alignment = [System.Drawing.StringAlignment]::Far
      $label = if ($cells.Count -gt 0) { $cells[0] } else { '' }; $qty = if ($cells.Count -gt 1) { $cells[1] } else { '' }; $price = if ($cells.Count -gt 2) { $cells[2] } else { '' }; $amount = if ($cells.Count -gt 3) { $cells[3] } else { '' }
      $rowHeight = [Math]::Max($g.MeasureString($label, $font, $labelWidth, $near).Height, $g.MeasureString('Ag', $font).Height)
      $g.DrawString($label, $font, [System.Drawing.Brushes]::Black, (New-Object System.Drawing.RectangleF($left, $y, $labelWidth, $rowHeight + 3)), $near)
      $g.DrawString($qty, $font, [System.Drawing.Brushes]::Black, (New-Object System.Drawing.RectangleF($left + $labelWidth, $y, $qtyWidth, $rowHeight + 3)), $right)
      $g.DrawString($price, $font, [System.Drawing.Brushes]::Black, (New-Object System.Drawing.RectangleF($left + $labelWidth + $qtyWidth, $y, $priceWidth, $rowHeight + 3)), $right)
      $g.DrawString($amount, $font, [System.Drawing.Brushes]::Black, (New-Object System.Drawing.RectangleF($left + $labelWidth + $qtyWidth + $priceWidth, $y, $amountWidth, $rowHeight + 3)), $right)
      $y += [Math]::Ceiling($rowHeight) + $(if ($isHead) { 5 } else { 4 }); $font.Dispose(); $near.Dispose(); $right.Dispose(); continue
    }
    if ($line.StartsWith('__COMPACTTOTAL__')) {
      $cells = $line.Substring(16).Split('|'); $font = New-Object System.Drawing.Font('Consolas', [Math]::Min(${totalFontSize}, 10), [System.Drawing.FontStyle]::Bold); $left = $contentLeft
      $near = New-Object System.Drawing.StringFormat; $near.Alignment = [System.Drawing.StringAlignment]::Near; $right = New-Object System.Drawing.StringFormat; $right.Alignment = [System.Drawing.StringAlignment]::Far; $height = $g.MeasureString('Ag', $font).Height
      $g.DrawString($(if ($cells.Count -gt 0) { $cells[0] } else { '' }), $font, [System.Drawing.Brushes]::Black, (New-Object System.Drawing.RectangleF($left, $y, $width * .7, $height + 3)), $near)
      $g.DrawString($(if ($cells.Count -gt 1) { $cells[1] } else { '' }), $font, [System.Drawing.Brushes]::Black, (New-Object System.Drawing.RectangleF($left + ($width * .7), $y, $width * .3, $height + 3)), $right)
      $y += [Math]::Ceiling($height) + 4; $font.Dispose(); $near.Dispose(); $right.Dispose(); continue
    }
    if ($line.StartsWith('__SUMMARY__') -or $line.StartsWith('__TOTAL__')) {
      $cells = $line.Substring($(if ($line.StartsWith('__SUMMARY__')) { 11 } else { 9 })).Split('|')
      $isTotal = $line.StartsWith('__TOTAL__'); $style = if ($isTotal) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular }; $size = if ($isTotal) { ${totalFontSize} } else { ${dateBillFontSize} }
      $font = New-Object System.Drawing.Font('${fontFamily}', $size, $style); $left = $contentLeft
      # The subtotal spans the full printable width. Grand Total may be inset
      # per printer, using its saved Grand total content width setting.
      if ($isTotal -and ${paperWidth} -eq 80) { $rowWidth = [Math]::Min($width, ${grandTotalWidth}); $left += [Math]::Max(0, ($width - $rowWidth) / 2) } else { $rowWidth = $width }
      $near = New-Object System.Drawing.StringFormat; $near.Alignment = [System.Drawing.StringAlignment]::Near; $right = New-Object System.Drawing.StringFormat; $right.Alignment = [System.Drawing.StringAlignment]::Far
      $height = $g.MeasureString('Ag', $font).Height
      $summaryLeft = if ($cells.Count) { $cells[0] } else { '' }; $summaryRight = if ($cells.Count -gt 1) { $cells[1] } else { '' }
      $summaryLine = if ($isTotal) { ('{0}: {1}' -f $summaryLeft, $summaryRight) } else { ('{0}    {1}' -f $summaryLeft, $summaryRight) }
      $g.DrawString($summaryLine, $font, [System.Drawing.Brushes]::Black, [single]$left, [single]$y)
      $y += [Math]::Ceiling($height) + $(if ($isTotal) { 6 } else { 3 }); $font.Dispose(); $near.Dispose(); $right.Dispose(); continue
    }
    if ($line.StartsWith('__KOTHEADER__')) { $displayLine = $line.Substring(13); $style = [System.Drawing.FontStyle]::${headerStyle}; $size = ${kotHeaderFontSize} }
    elseif ($line.StartsWith('__KOTTITLE__')) { $displayLine = $line.Substring(12); $style = [System.Drawing.FontStyle]::${headerStyle}; $size = ${kotTitleFontSize} }
    elseif ($line.StartsWith('__KOTCENTERMETABOLD__')) { $displayLine = $line.Substring(21); $alignment = [System.Drawing.StringAlignment]::Center; $style = [System.Drawing.FontStyle]::Bold; $size = ${kotMetaFontSize} }
    elseif ($line.StartsWith('__KOTCENTERMETA__')) { $displayLine = $line.Substring(17); $alignment = [System.Drawing.StringAlignment]::Center; $size = ${kotMetaFontSize} }
    elseif ($line.StartsWith('__KOTMETA__')) { $displayLine = $line.Substring(11); $alignment = [System.Drawing.StringAlignment]::Near; $size = ${kotMetaFontSize} }
    elseif ($line.StartsWith('__KOTMETABOLD__')) { $displayLine = $line.Substring(15); $alignment = [System.Drawing.StringAlignment]::Near; $style = [System.Drawing.FontStyle]::Bold; $size = ${kotMetaFontSize} }
    elseif ($line.StartsWith('__KOTITEM__')) { $displayLine = $line.Substring(11); $alignment = [System.Drawing.StringAlignment]::Near; $size = ${kotItemFontSize} }
    elseif ($line.StartsWith('__KOTNOTE__')) { $displayLine = $line.Substring(11); $alignment = [System.Drawing.StringAlignment]::Near; $size = ${kotMetaFontSize} }
    elseif ($line.StartsWith('__KOTFOOTER__')) { $displayLine = $line.Substring(13); $style = [System.Drawing.FontStyle]::${footerStyle}; $size = ${kotFooterFontSize} }
    elseif ($line.StartsWith('__KOT_PRINTER__')) { $displayLine = $line.Substring(15); $style = [System.Drawing.FontStyle]::${headerStyle}; $size = ${kotTitleFontSize} }
    elseif ($line.StartsWith('__TITLE__')) { $displayLine = $line.Substring(9); $style = [System.Drawing.FontStyle]::${headerStyle}; $size = ${restaurantFontSize} }
    elseif ($line.StartsWith('__BILLTITLE__')) { $displayLine = $line.Substring(13); $style = [System.Drawing.FontStyle]::${headerStyle}; $size = ${restaurantFontSize} }
    elseif ($line.StartsWith('__BILLHEADER__')) { $displayLine = $line.Substring(14); $style = [System.Drawing.FontStyle]::Bold; $size = ${headerFooterFontSize} }
    elseif ($line.StartsWith('__SUBTITLE__')) { $displayLine = $line.Substring(12); $size = ${headerFooterFontSize} }
    elseif ($line.StartsWith('__FOOTER__')) { $displayLine = $line.Substring(10); $style = [System.Drawing.FontStyle]::${footerStyle}; $size = ${headerFooterFontSize} }
    elseif ($line.StartsWith('__DATEBILL__')) { $displayLine = $line.Substring(12); $alignment = [System.Drawing.StringAlignment]::Near; $size = ${dateBillFontSize} }
    elseif ($line.StartsWith('__META__')) { $displayLine = $line.Substring(8); $alignment = [System.Drawing.StringAlignment]::Near; $size = ${dateBillFontSize} }
    elseif ($line.StartsWith('__METABOLD__')) { $displayLine = $line.Substring(12); $alignment = [System.Drawing.StringAlignment]::Near; $style = [System.Drawing.FontStyle]::Bold; $size = ${dateBillFontSize} }
    elseif ($line.StartsWith('__CENTER__')) { $displayLine = $line.Substring(10) }
    elseif ($line.StartsWith('__LEFT__')) { $displayLine = $line.Substring(8); $alignment = [System.Drawing.StringAlignment]::Near }
    elseif ($line.StartsWith('__MONO__')) { $displayLine = $line.Substring(8); $alignment = [System.Drawing.StringAlignment]::Near; $size = 13; $fontName = 'Consolas' }
    elseif ($line.StartsWith('__LABEL__')) { $displayLine = $line.Substring(9); $alignment = [System.Drawing.StringAlignment]::Near; $style = [System.Drawing.FontStyle]::Bold; $size = ${dateBillFontSize} }
    elseif ($line.StartsWith('__ITEMLABEL__')) { $displayLine = $line.Substring(13); $alignment = [System.Drawing.StringAlignment]::Near; $style = [System.Drawing.FontStyle]::Bold; $size = ${itemFontSize} }
    elseif ($line.StartsWith('__ITEMTEXT__')) { $displayLine = $line.Substring(12); $alignment = [System.Drawing.StringAlignment]::Near; $size = ${itemFontSize} }
    elseif ($line.StartsWith('__GRIDHEAD__')) { $displayLine = $line.Substring(12); $alignment = [System.Drawing.StringAlignment]::Near; $style = [System.Drawing.FontStyle]::Bold; $size = [Math]::Min(10, ${itemFontSize}); $fontName = 'Consolas' }
    elseif ($line.StartsWith('__GRID__')) { $displayLine = $line.Substring(8); $alignment = [System.Drawing.StringAlignment]::Near; $size = [Math]::Min(10, ${itemFontSize}); $fontName = 'Consolas' }
    elseif ($line.StartsWith('__GRAND__')) { $displayLine = $line.Substring(9); $alignment = [System.Drawing.StringAlignment]::Near; $style = [System.Drawing.FontStyle]::Bold; $size = ${totalFontSize} }
    elseif ($line.StartsWith('__TABLE__')) { $displayLine = $line.Substring(9); $alignment = [System.Drawing.StringAlignment]::Near; $size = ${itemFontSize} }
    elseif ($line.StartsWith('__TABLEHEAD__')) { $displayLine = $line.Substring(13); $alignment = [System.Drawing.StringAlignment]::Near; $style = [System.Drawing.FontStyle]::Bold; $size = ${totalFontSize} }
    elseif ($line -match '^(KOT|Order) #') { $style = [System.Drawing.FontStyle]::Bold; $size = 15 }
    elseif ($line -match '^\\d+x ') { $style = [System.Drawing.FontStyle]::Bold; $size = 11 }
    if ($line.StartsWith('__SUBTITLE__') -or $line.StartsWith('__CENTER__')) { $size = $bodySize }
    if (-not $fontName) { $fontName = '${fontFamily}' }
    $font = New-Object System.Drawing.Font($fontName, $size, $style)
    $format = New-Object System.Drawing.StringFormat; $format.Alignment = $alignment
    if ($line -match '^\\d+x ') { $format.Alignment = [System.Drawing.StringAlignment]::Near }
    $bounds = New-Object System.Drawing.RectangleF($contentLeft, $y, $width, 200)
    $height = $g.MeasureString($displayLine, $font, $width, $format).Height
    $g.DrawString($displayLine, $font, [System.Drawing.Brushes]::Black, $bounds, $format)
    $extra = if ($line.StartsWith('__TABLE__') -or $line.StartsWith('__KOTITEM__')) { ${itemGap} } elseif ($line.StartsWith('__SEPARATOR__')) { ${separatorGap} } elseif ($line.StartsWith('__META__') -or $line.StartsWith('__MONO__')) { 0 } else { 1 }; $y += [Math]::Max([Math]::Ceiling($height), ${itemMinHeight}) + $extra; $font.Dispose(); $format.Dispose()
  }
})
$doc.Print()`;
      await run('powershell.exe', ['-NoProfile', '-Command', script], PRINT_COMMAND_TIMEOUT_MS);
    } else {
      await run('lp', ['-d', printerName, file], PRINT_COMMAND_TIMEOUT_MS);
    }
  } finally {
    await fs.unlink(file).catch(() => {});
  }
}

function kotHighlightLabels(items) {
  const words = (value) =>
    String(value || '')
      .toLowerCase()
      .match(/[a-z]+/g) || [];
  const labels = items.map((item) => item.name || 'Item');
  const sets = labels.map((label) => new Set(words(label)));
  return labels.map((label, index) => {
    if (labels.length < 2) return label;
    const own = [...sets[index]];
    let nearest = null,
      overlap = -1;
    sets.forEach((candidate, candidateIndex) => {
      if (candidateIndex === index) return;
      const shared = own.filter((word) => candidate.has(word)).length;
      if (shared > overlap) {
        overlap = shared;
        nearest = candidate;
      }
    });
    const distinctive = own
      .filter((word) => !nearest?.has(word))
      .sort((a, b) => b.length - a.length)[0];
    if (!distinctive) return label;
    return label.replace(new RegExp(`\\b(${distinctive})\\b`, 'i'), '[[$1]]');
  });
}

function kotText(payload) {
  const order = payload.order || {};
  const settings = payload.settings || {};
  const items = Array.isArray(payload.items) ? payload.items : [];
  const tableLine =
    order.tableArea || order.tableNumber
      ? `Table: ${order.tableArea || 'Dining'} · ${order.tableNumber || '—'}`
      : order.fulfillment
        ? `Order: ${order.fulfillment}`
        : '';
  const guestLine = `Guest: ${order.customer || 'Walk-in customer'}`;
  const source = String(order.source || '').toLowerCase();
  const originLine =
    source === 'captain' && order.captainName
      ? `Captain / Waiter: ${order.captainName}`
      : source === 'qr'
        ? 'QR Code Order'
        : 'Counter Order';
  const qrGuestLine = order.customerPhone
    ? `Guest: ${order.customer || 'Guest'} · ${order.customerPhone}`
    : guestLine;
  const isRunningTable = order.mode === 'table' && Number(order.kotNumber) > 1;
  const metaLine = settings.kotDetailsCentered ? '__KOTCENTERMETA__' : '__KOTMETA__';
  const boldMetaLine = settings.kotDetailsCentered ? '__KOTCENTERMETABOLD__' : '__KOTMETABOLD__';
  const labels = kotHighlightLabels(items);
  const rows = items.flatMap((item, index) =>
    [
      `__KOTITEM__${Number(item.quantity || 0)}|${settings.showItemSerial ? `${index + 1}. ` : ''}${labels[index]}`,
      [item.portion ? `(${item.portion})` : '', item.style || ''].filter(Boolean).join(' ')
        ? `__KOTMODIFIER__${[item.portion ? `(${item.portion})` : '', item.style || ''].filter(Boolean).join(' ')}`
        : '',
      Addons.modifierText(item.modifiers)
        ? `__KOTMODIFIER__+ ${Addons.modifierText(item.modifiers)}`
        : '',
      item.note ? `__KOTNOTE__↳ ${item.note}` : '',
    ].filter(Boolean)
  );
  const savedFeed = Number(settings.kotBottomFeedLines);
  const bottomLines =
    (Number.isFinite(savedFeed) ? Math.max(0, Math.min(12, savedFeed)) : 3) +
    Math.max(0, Math.min(2, Number(settings.extraSpace) || 0)) * 2;
  return [
    order.reprint ? '__KOTCENTERMETABOLD__DUPLICATE COPY' : '',
    isRunningTable ? '__KOTCENTERMETABOLD__RUNNING TABLE' : '',
    `${boldMetaLine}KOT # ${order.kotNumber || '—'}`,
    order.waiterName ? `${metaLine}Waiter: ${order.waiterName}` : '',
    order.servicePriority === 'urgent' ? `${boldMetaLine}URGENT` : '',
    tableLine ? `${metaLine}${tableLine}` : '',
    `${metaLine}${originLine}`,
    settings.showCustomer !== false
      ? `${metaLine}${source === 'qr' ? qrGuestLine : guestLine}`
      : '',
    '__KOTRULE__',
    '__KOTMETABOLD__Qty. Item',
    ...rows,
    order.note && settings.showNotes !== false ? `__KOTNOTE__Note: ${order.note}` : '',
    '__KOTRULE__',
    '\n'.repeat(bottomLines),
  ]
    .filter(Boolean)
    .join('\n');
}
function billText(payload) {
  const order = payload.order || {},
    settings = payload.settings || {},
    items = Array.isArray(order.items) ? order.items : [],
    line = '__SEPARATOR__';
  const sectionHeight = (key, fallback) => {
    const parsed = Number(settings[key]);
    return Math.max(0, Math.min(500, Number.isFinite(parsed) ? parsed : fallback));
  };
  const money = (value) => `₹${Math.round(Number(value) || 0)}`;
  const decimal = (value) => (Number(value) || 0).toFixed(2);
  const itemPrice = (item) =>
    Number(String(item.price || '').replace(/[^0-9.]/g, '')) +
    (item.style ? 10 : 0) +
    Addons.lineModifierTotal(item);
  const subtotal = items.reduce(
    (sum, item) => sum + itemPrice(item) * Number(item.quantity || 0),
    0
  );
  const total =
    order.total != null && Number.isFinite(Number(order.total)) && Number(order.total) >= 0
      ? Number(order.total)
      : subtotal;
  const walletDiscount = Math.max(0, Math.floor(Number(order.loyalty_points_redeemed || 0)));
  const itemRows = items.flatMap((item, index) => {
    const label = `${settings.showItemSerial ? `${index + 1}. ` : ''}${item.name || 'Item'}${item.portion ? ` (${item.portion})` : ''}`;
    const quantity = Number(item.quantity || 0),
      unit = itemPrice(item),
      itemAmount = quantity * unit;
    return [
      `__ITEM__${label}|${quantity}|${decimal(unit)}|${decimal(itemAmount)}`,
      item.style ? `__ITEM__  ${item.style} gravy|||` : '',
      Addons.modifierText(item.modifiers)
        ? `__ITEM__  + ${Addons.modifierText(item.modifiers)}|||`
        : '',
    ].filter(Boolean);
  });
  const token = String(order.daily_order_number || '—').padStart(2, '0');
  const placedAt = order.created_at ? new Date(order.created_at) : new Date();
  const placedDate = new Intl.DateTimeFormat('en-IN', {
    timeZone: 'Asia/Kolkata',
    day: '2-digit',
    month: '2-digit',
    year: '2-digit',
  }).format(placedAt);
  const placedTime = new Intl.DateTimeFormat('en-IN', {
    timeZone: 'Asia/Kolkata',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(placedAt);
  const quantity = items.reduce((sum, item) => sum + Number(item.quantity || 0), 0);
  const billNumber = order.bill_number ? String(order.bill_number).padStart(2, '0') : '—';
  const customer = String(order.customer_name || '').trim();
  const phone = String(order.customer_phone || '').replace(/^walkin-.*$/i, '');
  const service =
    order.mode === 'table'
      ? `Dine In · ${order.table_area || 'Table'} ${order.table_number || ''}`.trim()
      : order.fulfillment_type === 'delivery'
        ? 'Delivery'
        : 'Parcel';
  const customerLine = customer
    ? `Name: ${customer}${phone ? ` (M: ${phone})` : ''}`
    : phone
      ? `Mobile: ${phone}`
      : 'Name: Walk-in customer';
  // Keep this as the same compact three-line block as the measured reference:
  // date/order type, cashier/bill number, then the emphasised token.
  const details = [
    line,
    `__META__${customerLine}`,
    `__META__Date: ${placedDate} ${placedTime}          ${service}`,
    `__META__Cashier: biller       Bill No.: ${billNumber}`,
    `__METABOLD__Token No.: ${token}`,
    line,
  ];
  const itemHeader = '__ITEMHEAD__Item|Qty|Price|Amount';
  const totals = [
    `__SUMMARY__Total Qty: ${quantity}|Sub Total: ${money(subtotal)}`,
    walletDiscount ? `__SUMMARY__Points discount|-${money(walletDiscount)}` : '',
    Number(order.discount_amount) > 0
      ? `__SUMMARY__Staff discount|-${money(Number(order.discount_amount))}`
      : '',
  ];
  const defaultHeader =
    'Colva Goa\n9922853605 / 9049558369\n[Follow] Insta ID:\nred_lantern_restaurant';
  const defaultFooter =
    'Thank you for choosing us!\nKindly leave us a review\nGoogle | Zomato | Swiggy';
  return [
    settings.reprint ? '__CENTER__*** REPRINT ***' : '',
    settings.showRestaurantName === false
      ? ''
      : `__BILLTITLE__${settings.restaurantName || 'Red Lantern Restaurant'}`,
    `__BILLHEADER__${settings.receiptHeader || defaultHeader}`,
    line,
    `__META__${customerLine}`,
    line,
    ...details.slice(2, -1),
    line,
    itemHeader,
    line,
    ...itemRows,
    line,
    ...totals,
    `__TOTAL__GRAND TOTAL|${money(total)}`,
    line,
    `__FOOTER__${settings.receiptFooter || defaultFooter}`,
    '\n\n\n',
  ]
    .filter(Boolean)
    .join('\n');
}

function allowedOrigin(request) {
  const origin = request.headers.origin || '';
  if (
    !origin ||
    /^https:\/\/(www\.)?redlanternrestaurant\.in$/i.test(origin) ||
    /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i.test(origin)
  )
    return origin || '*';
  return '';
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.setEncoding('utf8');
    req.on('data', (chunk) => {
      raw += chunk;
      if (raw.length > 512000) reject(new Error('Request too large.'));
    });
    req.on('end', () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch (_) {
        reject(new Error('Invalid JSON.'));
      }
    });
    req.on('error', reject);
  });
}

function reply(res, status, body, origin = '') {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    ...(origin
      ? {
          'Access-Control-Allow-Origin': origin,
          // Secure Orders PWAs call this loopback service from a public origin.
          // The origin has already passed the restaurant-only allowlist above.
          'Access-Control-Allow-Private-Network': 'true',
          Vary: 'Origin',
        }
      : {}),
    'Access-Control-Allow-Methods': 'GET, POST, PUT, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Cache-Control': 'no-store',
  });
  res.end(JSON.stringify(body));
}

const server = http.createServer(async (req, res) => {
  const origin = allowedOrigin(req);
  if (req.headers.origin && !origin)
    return reply(res, 403, { error: 'This website is not allowed to access the Print Bridge.' });
  if (req.method === 'OPTIONS') return reply(res, 204, {}, origin);
  // A browser cache-busting query must not turn a valid endpoint into a 404.
  const pathname = new URL(req.url, `http://127.0.0.1:${PORT}`).pathname;
  if (req.method === 'GET' && pathname === '/health') {
    try {
      localLedger().prepare('SELECT 1 AS ok').get();
      const workstation = await workstationIdentity();
      // Health is used before automatic KOT dispatch. Keep it independent of
      // the slower Windows spooler probe so a ready Bridge answers at once.
      const automaticRecovery = windowsSpoolerCheck.result;
      return reply(
        res,
        200,
        {
          ok: true,
          service: 'Red Lantern Print Bridge',
          pid: process.pid,
          version: BRIDGE_VERSION,
          protocolVersion: 1,
          capabilities: BRIDGE_CAPABILITIES,
          platform: process.platform,
          node: process.version,
          ledger: 'ready',
          workstation,
          automaticRecovery,
          ledgerSummary: ledgerSummary(),
        },
        origin
      );
    } catch (error) {
      return reply(
        res,
        503,
        {
          ok: false,
          service: 'Red Lantern Print Bridge',
          error: 'The local SQLite ledger is unavailable.',
          detail: error.message,
        },
        origin
      );
    }
  }
  if (req.method === 'GET' && pathname === '/v1/setup-status') {
    try {
      localLedger().prepare('SELECT 1 AS ok').get();
      // These checks do not depend on one another while the spooler is already
      // healthy (the normal case). Running them together avoids stacking four
      // separate PowerShell startup costs on every visit to Operations.
      const [automaticRecovery, workstation, printers, config, unavailableNames, networkEndpoints] =
        await Promise.all([
          ensureWindowsSpoolerRunning(),
          workstationIdentity(),
          installedPrinters(),
          readJson(configFile, { printers: [], routes: [] }),
          unavailablePrinterNames(),
          networkPrinterEndpoints(),
        ]);
      const savedPrinters = Array.isArray(config.printers) ? config.printers : [];
      const savedRoutes = Array.isArray(config.routes) ? config.routes : [];
      const installedNames = new Set(printers.map((printer) => String(printer.name).trim()));
      const binding = (printer) => resolveSystemPrinter(printer.deviceName, printers);
      // A saved queue with no active Bill or KOT capability is not part of the
      // restaurant's print path and must not make the entire workspace appear
      // offline. This also prevents old, unassigned queues from surviving as a
      // permanent false warning after a printer is replaced.
      const assignedPrinters = savedPrinters.filter(
        (printer) =>
          String(printer.deviceName || '').trim() &&
          printerMatchesWorkstation(printer, workstation, installedNames, printers) &&
          (printerSupports(printer, 'bill') || printerSupports(printer, 'kot'))
      );
      const configuredPrinters = assignedPrinters.filter((printer) => !!binding(printer));
      const missingConfiguredPrinters = assignedPrinters
        .filter((printer) => !binding(printer))
        .map((printer) => ({
          id: String(printer.id || ''),
          name: String(printer.name || ''),
          deviceName: String(printer.deviceName || ''),
        }));
      const networkChecks = await Promise.all(
        configuredPrinters.map(async (printer) => {
          const deviceName = String(printer.deviceName || '').trim();
          const endpoint = networkEndpoints.get(binding(printer)?.name || deviceName);
          if (!endpoint) return null;
          return {
            id: String(printer.id || ''),
            name: String(printer.name || ''),
            deviceName,
            host: endpoint.host,
            port: endpoint.port,
            reachable: await tcpEndpointReachable(endpoint.host, endpoint.port),
          };
        })
      );
      const networkStatus = networkChecks.filter(Boolean);
      const networkPrinterNames = new Set(networkStatus.map((printer) => printer.deviceName));
      // Thermal-printer drivers frequently leave PrinterStatus=Offline even
      // while their RAW TCP endpoint is accepting jobs. For LAN printers the
      // live socket probe is the stronger signal; use the Windows flag only for
      // local/USB queues where no network endpoint exists.
      const unavailableConfiguredPrinters = configuredPrinters
        .filter((printer) => {
          const deviceName = String(printer.deviceName || '').trim();
          const queue = binding(printer);
          const hardFailure = /Error|PaperOut|PaperJam|DoorOpen|UserIntervention/i.test(
            queue?.status || ''
          );
          // A live network port overrides a driver's stale Offline flag, but
          // cannot override a real paper jam, empty paper roll or queue error.
          return (
            unavailableNames.has(queue?.name || deviceName) &&
            (hardFailure || !networkPrinterNames.has(deviceName))
          );
        })
        .map((printer) => ({
          id: String(printer.id || ''),
          name: String(printer.name || ''),
          deviceName: String(printer.deviceName || ''),
        }));
      const unreachableConfiguredPrinters = networkStatus
        .filter((printer) => !printer.reachable)
        .map(({ reachable, ...printer }) => printer);
      const configuredKotIds = new Set(
        configuredPrinters
          .filter((printer) => printerSupports(printer, 'kot'))
          .map((printer) => String(printer.id))
      );
      const configuredKotRoutes = savedRoutes.filter((route) =>
        configuredKotIds.has(String(route.printerId))
      );
      return reply(
        res,
        200,
        {
          ok: true,
          platform: process.platform,
          platformLabel:
            process.platform === 'win32'
              ? 'Windows'
              : process.platform === 'darwin'
                ? 'macOS'
                : process.platform,
          version: BRIDGE_VERSION,
          protocolVersion: 1,
          capabilities: BRIDGE_CAPABILITIES,
          node: process.version,
          ledger: 'ready',
          automaticRecovery,
          workstation,
          printerCount: printers.length,
          // Return fresh discovery with readiness so a newly installed driver
          // appears in Operations after this same one-click check.
          printers,
          configuredPrinterCount: configuredPrinters.length,
          configuredPrinterIds: configuredPrinters.map((printer) => String(printer.id || '')),
          printerBindings: configuredPrinters.map((printer) => ({
            id: String(printer.id || ''),
            deviceName: String(printer.deviceName || ''),
            queueName: binding(printer).name,
          })),
          configuredBillPrinterCount: configuredPrinters.filter((printer) =>
            printerSupports(printer, 'bill')
          ).length,
          configuredKotRouteCount: configuredKotRoutes.length,
          uniqueKotRouteTargetCount: new Set(
            configuredKotRoutes.map(
              (route) =>
                `${String(route.category || '')}::${String(route.itemName || '')}::${String(route.portion || '')}`
            )
          ).size,
          hasWildcardKotRoute: configuredKotRoutes.some(
            (route) => route.category === '*' && !route.itemName && !route.portion
          ),
          missingConfiguredPrinterCount: missingConfiguredPrinters.length,
          missingConfiguredPrinters,
          unavailableConfiguredPrinterCount: unavailableConfiguredPrinters.length,
          unavailableConfiguredPrinters,
          unreachableConfiguredPrinterCount: unreachableConfiguredPrinters.length,
          unreachableConfiguredPrinters,
          routeCount: savedRoutes.length,
          ledgerSummary: ledgerSummary(),
          recentPrintFailures: recentPrintFailures(),
        },
        origin
      );
    } catch (error) {
      return reply(
        res,
        503,
        { ok: false, error: 'Print Bridge needs attention.', detail: error.message },
        origin
      );
    }
  }
  if (req.method === 'POST' && pathname === '/v1/restart') {
    reply(res, 202, { ok: true, message: 'Print Bridge is restarting.' }, origin);
    setTimeout(() => {
      // The installed supervisor immediately replaces this child. Do not create
      // a detached process here: detached replacements escape Task Scheduler
      // and were the cause of later unrecovered bridge outages.
      if (process.env.PRINT_BRIDGE_SUPERVISED === '1') {
        shutdown(75);
        return;
      }
      const child = spawn(process.execPath, [__filename], {
        cwd: __dirname,
        detached: true,
        stdio: 'ignore',
        windowsHide: true,
      });
      child.unref();
      shutdown(0);
    }, 250).unref();
    return;
  }
  if (req.method === 'GET' && pathname === '/v1/printers') {
    try {
      return reply(
        res,
        200,
        { printers: await installedPrinters(), workstation: await workstationIdentity() },
        origin
      );
    } catch (error) {
      return reply(
        res,
        500,
        { error: 'Unable to read installed printers.', detail: error.message },
        origin
      );
    }
  }
  if (req.method === 'GET' && pathname === '/v1/config') {
    try {
      return reply(
        res,
        200,
        { config: await readJson(configFile, { printers: [], routes: [] }) },
        origin
      );
    } catch (error) {
      return reply(
        res,
        500,
        { error: 'Unable to read local printer configuration.', detail: error.message },
        origin
      );
    }
  }
  if (req.method === 'PUT' && pathname === '/v1/config') {
    try {
      const payload = await readBody(req);
      const result = await saveLocalPrinterConfig(payload);
      return reply(res, 200, result, origin);
    } catch (error) {
      return reply(
        res,
        400,
        { error: error.message || 'Unable to save local printer configuration.' },
        origin
      );
    }
  }
  if (req.method === 'GET' && req.url.startsWith('/v1/ledger/actions')) {
    try {
      const requested =
        new URL(req.url, `http://127.0.0.1:${PORT}`).searchParams.get('status') || 'queued';
      const statuses =
        requested === 'all'
          ? ['queued', 'syncing', 'blocked', 'synced']
          : requested
              .split(',')
              .filter((status) => ['queued', 'syncing', 'blocked'].includes(status));
      const rows = statuses.length
        ? localLedger()
            .prepare(
              `SELECT * FROM ledger_actions WHERE status IN (${statuses.map(() => '?').join(',')}) ORDER BY created_at ASC LIMIT 500`
            )
            .all(...statuses)
        : [];
      return reply(res, 200, { actions: rows.map(ledgerAction) }, origin);
    } catch (error) {
      return reply(
        res,
        500,
        { error: 'Unable to read the local order ledger.', detail: error.message },
        origin
      );
    }
  }
  if (req.method === 'POST' && pathname === '/v1/print-jobs/acknowledge') {
    try {
      const body = await readBody(req);
      return reply(res, 200, { ok: true, acknowledged: acknowledgePrintJobs(body.ids) }, origin);
    } catch (error) {
      return reply(
        res,
        400,
        { error: error.message || 'Unable to acknowledge print jobs.' },
        origin
      );
    }
  }
  if (req.method === 'POST' && pathname === '/v1/ledger/actions') {
    try {
      return reply(res, 201, { ok: true, action: queueLedgerAction(await readBody(req)) }, origin);
    } catch (error) {
      return reply(
        res,
        400,
        { error: error.message || 'Unable to save the offline order.' },
        origin
      );
    }
  }
  const ledgerUpdateMatch = req.url.match(/^\/v1\/ledger\/actions\/([^/]+)\/(synced|blocked)$/);
  if (req.method === 'POST' && ledgerUpdateMatch) {
    try {
      const body = await readBody(req);
      return reply(
        res,
        200,
        {
          ok: true,
          action: updateLedgerAction(
            decodeURIComponent(ledgerUpdateMatch[1]),
            ledgerUpdateMatch[2],
            body.error
          ),
        },
        origin
      );
    } catch (error) {
      return reply(
        res,
        400,
        { error: error.message || 'Unable to update the offline order.' },
        origin
      );
    }
  }
  if (req.method === 'GET' && pathname === '/v1/kot-queue') {
    try {
      return reply(res, 200, { jobs: await readJson(queueFile, []) }, origin);
    } catch (error) {
      return reply(
        res,
        500,
        { error: 'Unable to read local KOT queue.', detail: error.message },
        origin
      );
    }
  }
  if (req.method === 'POST' && pathname === '/v1/kot-queue') {
    try {
      const payload = await readBody(req);
      await assertRequestedWorkstation(payload);
      const printerId = String(payload.printerId || '').slice(0, 60);
      const items = Array.isArray(payload.items) ? payload.items.slice(0, 100) : [];
      if (!printerId || !items.length)
        throw new Error('A KOT needs a printer and at least one item.');
      const jobs = await readJson(queueFile, []);
      const job = {
        id: crypto.randomUUID(),
        status: 'queued',
        queuedAt: new Date().toISOString(),
        order: payload.order || null,
        printerId,
        items,
      };
      jobs.push(job);
      await writeJson(queueFile, jobs.slice(-1000));
      return reply(res, 201, { ok: true, job }, origin);
    } catch (error) {
      return reply(res, 400, { error: error.message || 'Unable to queue KOT.' }, origin);
    }
  }
  if (req.method === 'POST' && pathname === '/v1/test-print') {
    try {
      const payload = await readBody(req);
      await assertRequestedWorkstation(payload);
      const requestedPrinter = String(payload.printerName || '')
        .trim()
        .slice(0, 160);
      if (!requestedPrinter) throw new Error('Assign an installed system printer before testing.');
      const printerName = await resolvePrintQueue(requestedPrinter);
      const label = String(payload.label || printerName)
        .trim()
        .slice(0, 80);
      const role = payload.type === 'bill' ? 'BILL PRINTER' : 'KOT PRINTER';
      const timestamp = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });
      const testText = [
        '__CENTER__RED LANTERN',
        '__SEPARATOR__',
        '__CENTER__TEST PRINT SUCCESSFUL',
        '',
        `Printer: ${label}`,
        `System queue: ${printerName}`,
        `Role: ${role}`,
        `Checked: ${timestamp}`,
        '',
        'This printer is connected and ready.',
        '__SEPARATOR__',
        '',
        '',
      ].join('\n');
      await printText(printerName, testText, payload.settings || {});
      return reply(res, 200, { ok: true, printerName }, origin);
    } catch (error) {
      return reply(
        res,
        400,
        { error: 'Test print failed.', detail: error.message || 'Unable to print.' },
        origin
      );
    }
  }
  if (req.method === 'POST' && pathname === '/v1/print-kot') {
    let printJobId = '';
    try {
      const payload = await readBody(req);
      await assertRequestedWorkstation(payload);
      printJobId = String(payload.printJobId || '');
      const requestedPrinter = String(payload.printerName || '')
        .trim()
        .slice(0, 160);
      const printerName = await resolvePrintQueue(requestedPrinter);
      const items = Array.isArray(payload.items) ? payload.items.slice(0, 100) : [];
      if (!printerName || !items.length)
        throw new Error('A printer and at least one KOT item are required.');
      const ticketText = kotText({ ...payload, items });
      const contentHash = crypto.createHash('sha256').update(ticketText).digest('hex');
      const claim = claimPrintJob(payload.printJobId, 'kot', printerName, contentHash);
      if (!claim.claim)
        return reply(
          res,
          claim.duplicate ? 200 : claim.uncertain ? 409 : 202,
          {
            ok: !!claim.duplicate || !!claim.pending,
            duplicate: !!claim.duplicate,
            contentChanged: !!claim.contentChanged,
            pending: !!claim.pending,
            uncertain: !!claim.uncertain,
            printerName,
            ...(claim.uncertain
              ? {
                  error:
                    'The previous print attempt ended unexpectedly. Check for a physical slip, then use the explicit Reprint action if another copy is needed.',
                }
              : {}),
          },
          origin
        );
      await withPrintJobLease(payload.printJobId, () =>
        printText(printerName, ticketText, payload.settings || {})
      );
      finishPrintJob(payload.printJobId, 'printed');
      return reply(res, 201, { ok: true, printerName, itemCount: items.length }, origin);
    } catch (error) {
      try {
        finishPrintJob(
          printJobId,
          error?.killed || error?.signal || error?.code === 'ETIMEDOUT' ? 'uncertain' : 'failed'
        );
      } catch (_) {}
      return reply(res, 400, { error: error.message || 'Unable to print KOT.' }, origin);
    }
  }
  if (req.method === 'POST' && pathname === '/v1/print-bill') {
    let printJobId = '';
    try {
      const payload = await readBody(req);
      await assertRequestedWorkstation(payload);
      printJobId = String(payload.printJobId || '');
      const requestedPrinter = String(payload.printerName || '')
        .trim()
        .slice(0, 160);
      const printerName = await resolvePrintQueue(requestedPrinter);
      if (!printerName || !payload.order?.id)
        throw new Error('A bill printer and order are required.');
      const claim = claimPrintJob(payload.printJobId, 'bill', printerName);
      if (!claim.claim)
        return reply(
          res,
          claim.duplicate ? 200 : claim.uncertain ? 409 : 202,
          {
            ok: !!claim.duplicate || !!claim.pending,
            duplicate: !!claim.duplicate,
            contentChanged: !!claim.contentChanged,
            pending: !!claim.pending,
            uncertain: !!claim.uncertain,
            printerName,
            ...(claim.uncertain
              ? {
                  error:
                    'The previous print attempt ended unexpectedly. Check for a physical bill, then use the explicit Reprint action if another copy is needed.',
                }
              : {}),
          },
          origin
        );
      await withPrintJobLease(payload.printJobId, () =>
        printText(printerName, billText(payload), payload.settings || {})
      );
      finishPrintJob(payload.printJobId, 'printed');
      return reply(res, 201, { ok: true, printerName }, origin);
    } catch (error) {
      try {
        finishPrintJob(
          printJobId,
          error?.killed || error?.signal || error?.code === 'ETIMEDOUT' ? 'uncertain' : 'failed'
        );
      } catch (_) {}
      return reply(res, 400, { error: error.message || 'Unable to print bill.' }, origin);
    }
  }
  return reply(res, 404, { error: 'Not found.' }, origin);
});
server.on('error', (error) => {
  console.error(`Red Lantern Print Bridge could not start: ${error.message}`);
  closeLedger();
  process.exitCode = 1;
});
if (require.main === module) {
  process.on('SIGINT', () => shutdown(0));
  process.on('SIGTERM', () => shutdown(0));
  server.listen(PORT, '127.0.0.1', () => {
    console.log(`Red Lantern Print Bridge is running at http://127.0.0.1:${PORT}`);
    // Keep Windows printing healthy without asking restaurant staff to open
    // Services or restart the spooler. The cached probe prevents browser
    // health checks from spawning extra PowerShell processes.
    void ensureWindowsSpoolerRunning({ force: true });
    const recoveryMonitor = setInterval(
      () => void ensureWindowsSpoolerRunning({ force: true }),
      60000
    );
    recoveryMonitor.unref();
  });
}

module.exports = {
  kotText,
  billText,
  run,
  server,
  closeLedger,
  installedPrinters,
  networkPrinterEndpoints,
  windowsPrinterSnapshot,
  ensureWindowsSpoolerRunning,
  resolvePrintQueue,
};
