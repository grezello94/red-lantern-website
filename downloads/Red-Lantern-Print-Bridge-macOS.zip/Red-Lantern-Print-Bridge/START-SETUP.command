#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
bash ./install-print-bridge-macos.sh
echo
read -r -p "Press Return to close…"
