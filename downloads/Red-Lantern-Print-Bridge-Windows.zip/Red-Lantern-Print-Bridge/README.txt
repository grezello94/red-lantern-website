Red Lantern Print Bridge

1. Install Node.js 22 or newer from https://nodejs.org if it is not already installed.
2. Double-click START-SETUP.cmd.
3. Return to Orders > Operations > Print & offline setup and choose Check again.

The Bridge stays local to this computer and stores its offline SQLite ledger in
your user profile. Do not expose port 9124 to the public internet.
