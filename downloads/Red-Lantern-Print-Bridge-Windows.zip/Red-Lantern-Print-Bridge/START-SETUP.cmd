@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\install-print-bridge-windows.ps1"
if errorlevel 1 pause
